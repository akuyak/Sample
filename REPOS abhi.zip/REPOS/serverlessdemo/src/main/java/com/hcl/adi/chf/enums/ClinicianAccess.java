package com.hcl.adi.chf.enums;

/**
 * Enumeration to define clinician access
 *
 * @author AyushRa
 */
public enum ClinicianAccess {
	WEB, MOBILE
}